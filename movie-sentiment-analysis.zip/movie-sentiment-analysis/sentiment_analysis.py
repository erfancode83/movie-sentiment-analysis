import os
import pandas as pd
from transformers import pipeline

# ================================
# 1) ساخت پوشه و داده نمونه
# ================================
os.makedirs("data", exist_ok=True)

reviews = [
    "Absolutely loved Joker, Joaquin Phoenix was phenomenal.",
    "The movie was too dark and depressing for me.",
    "Brilliant storytelling, kept me hooked till the end.",
    "Too violent, not my type of film.",
    "Masterpiece! One of the best movies of the decade.",
    "I didn’t understand the hype, it was just okay.",
    "Incredible acting and cinematography.",
    "The pacing was slow and boring.",
    "A chilling performance by Joaquin Phoenix.",
    "Overrated, I expected more.",
] * 5  # تکرار برای رسیدن به 50 ریویو

df = pd.DataFrame(reviews, columns=["review"])
df.to_csv("data/joker_reviews.csv", index=False)
print("✅ Reviews saved to CSV!")

# ================================
# 2) بارگذاری داده و مدل
# ================================
df = pd.read_csv("data/joker_reviews.csv")

sentiment_analyzer = pipeline("sentiment-analysis")

# ================================
# 3) اجرای تحلیل روی همه ریویوها
# ================================
results = sentiment_analyzer(df["review"].tolist())

df["sentiment"] = [r["label"] for r in results]
df["score"] = [r["score"] for r in results]

df.to_csv("data/joker_reviews_with_sentiment.csv", index=False)

print("✅ Sentiment analysis finished! File saved as 'data/joker_reviews_with_sentiment.csv'\n")

# ================================
# 4) خلاصه آماری
# ================================
summary = df["sentiment"].value_counts()
positive_avg = df[df["sentiment"] == "POSITIVE"]["score"].mean()
negative_avg = df[df["sentiment"] == "NEGATIVE"]["score"].mean()

print("📊 Sentiment Summary:")
print(summary)
print(f"\n🔹 Average confidence for POSITIVE reviews: {positive_avg:.2f}")
print(f"🔹 Average confidence for NEGATIVE reviews: {negative_avg:.2f}")

print("\n📌 نمونه خروجی:")
print(df.head(10))
